import React from 'react'

import './FeatureItem.css'

export default function FeatureItem() {
    return (
        <div className="feature-item-container">
            <img src="https://via.placeholder.com/85"/>
            <h4>Title placed here</h4>
            <p>Lors consequuntur, tempore recusandae atque laborum aperiam quis ea consequatur laudantium dolorem.</p>
        </div>
    )
}
